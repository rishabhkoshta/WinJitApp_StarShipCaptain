﻿

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WinJitApp_StarShipCaptain.Models;

namespace WinJitApp_StarShipCaptain.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        [HttpPost]
        public ActionResult Index(string home_x, String home_y, String home_z)
        {

            Random rand = new Random();
            string new_planet_cor_x2,new_planet_cor_y2,new_planet_cor_z2;

            try
            {
                new_planet_cor_x2 = rand.Next(1000000000).ToString(@"000\.000\.00\.0");
                new_planet_cor_y2 = rand.Next(1000000000).ToString(@"000\.000\.00\.0");
                new_planet_cor_z2 = rand.Next(1000000000).ToString(@"000\.000\.00\.0");

                CoordinateModel Object_CoordinateModel = new CoordinateModel();              
                Object_CoordinateModel.GetCoordinatesData(home_x, home_y, home_z, new_planet_cor_x2, new_planet_cor_y2, new_planet_cor_z2);
                Object_CoordinateModel.New_Plante_Area = Object_CoordinateModel.CalcNewSurfaceArea();
                // Condtion to check plante is IshHabitable
                if (Object_CoordinateModel.New_Plante_Area > 1 && Object_CoordinateModel.New_Plante_Area < 100000000) 
                {
                    Object_CoordinateModel.IshHabitable = true;
                }
                Object_CoordinateModel.ColonizedAreaValue = Object_CoordinateModel.ColonizedArea();
                return View("NewPlanetCordinate", Object_CoordinateModel);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpPost]
        public ActionResult About(string X1, string Y1, string Z1, string X2, string Y2, string Z2, string NewPlArea, bool IshHabitable, string ColonizedAreaValue)
        {

            try
            {
                
                string fileName =  String.Format("{0:yyyy-MM-dd}__{1}", DateTime.Now, "Report.txt");
                string path = Path.Combine("D:\\", fileName);
                FileStream Object_fs = new FileStream(path, FileMode.Create, FileAccess.Write);
                StreamWriter Object_sw = new StreamWriter(Object_fs);
                Object_sw.WriteLine("Report - " + DateTime.Today.ToShortDateString());
                Object_sw.WriteLine("Home Planet Coordinates:");
                Object_sw.WriteLine("X: " + X1);
                Object_sw.WriteLine("Y: " + Y1);
                Object_sw.WriteLine("Z: " + Z1);
                Object_sw.WriteLine("New Planet Coordinates:");
                Object_sw.WriteLine("X: " + X2);
                Object_sw.WriteLine("Y: " + Y2);
                Object_sw.WriteLine("Z: " + Z2);
                Object_sw.WriteLine("New Planet Surface Area!: " + NewPlArea);
                Object_sw.WriteLine("Is this Planet Hbitable? " + IshHabitable);
                Object_sw.WriteLine("Colonized Output: " + ColonizedAreaValue);
                Object_sw.WriteLine("");
                Object_sw.Close();
                ViewBag.FilePath = path;

            }
            catch (Exception ex)
            {
                throw ex;
            }

            ViewBag.Message = "Report has been generated successfully";
            
            return View();
        }
    }
}
