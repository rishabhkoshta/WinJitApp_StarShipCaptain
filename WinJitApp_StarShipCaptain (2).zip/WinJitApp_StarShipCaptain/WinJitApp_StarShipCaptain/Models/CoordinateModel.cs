﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;

namespace WinJitApp_StarShipCaptain.Models
{
    public class CoordinateModel
    {

            public uint value; 
            public string New_X1, New_Y1, New_Z1, New_X2, New_Y2, New_Z2;
            public uint valueX1, valueY1, valueZ1, valueX2, valueY2, valueZ2;
            public double X2, X1, Y2, Y1, Z2, Z1;
            public double Distance = 0.0;
            public double New_Plante_Area;
            public bool IshHabitable = false;
            public double ColonizedAreaValue;
                     
            public void GetCoordinatesData(string text_X1, string text_Y1, string text_Z1, string text_X2, string text_Y2, string text_Z2)
            {
                Match MatchX1 = Regex.Match(text_X1, @"^([0-9]{3})\.([0-9]{3})\.([0-9]{2})\.([0-9])$"); 
                Match MatchY1 = Regex.Match(text_Y1, @"^([0-9]{3})\.([0-9]{3})\.([0-9]{2})\.([0-9])$"); 
                Match MatchZ1 = Regex.Match(text_Z1, @"^([0-9]{3})\.([0-9]{3})\.([0-9]{2})\.([0-9])$"); 

                Match MatchX2 = Regex.Match(text_X2, @"^([0-9]{3})\.([0-9]{3})\.([0-9]{2})\.([0-9])$"); 
                Match MatchY2 = Regex.Match(text_Y2, @"^([0-9]{3})\.([0-9]{3})\.([0-9]{2})\.([0-9])$"); 
                Match MatchZ2 = Regex.Match(text_Z2, @"^([0-9]{3})\.([0-9]{3})\.([0-9]{2})\.([0-9])$"); 


                valueX1 = uint.Parse(MatchX1.Groups[1].Value + MatchX1.Groups[2].Value + MatchX1.Groups[3].Value + MatchX1.Groups[4].Value); 
                valueY1 = uint.Parse(MatchY1.Groups[1].Value + MatchY1.Groups[2].Value + MatchY1.Groups[3].Value + MatchY1.Groups[4].Value); 
                valueZ1 = uint.Parse(MatchZ1.Groups[1].Value + MatchZ1.Groups[2].Value + MatchZ1.Groups[3].Value + MatchZ1.Groups[4].Value); 

                valueX2 = uint.Parse(MatchX2.Groups[1].Value + MatchX2.Groups[2].Value + MatchX2.Groups[3].Value + MatchX2.Groups[4].Value); 
                valueY2 = uint.Parse(MatchY2.Groups[1].Value + MatchY2.Groups[2].Value + MatchY2.Groups[3].Value + MatchY2.Groups[4].Value); 
                valueZ2 = uint.Parse(MatchZ2.Groups[1].Value + MatchZ2.Groups[2].Value + MatchZ2.Groups[3].Value + MatchZ2.Groups[4].Value); 

                X1 = Convert.ToDouble(valueX1); 
                Y1 = Convert.ToDouble(valueY1); 
                Z1 = Convert.ToDouble(valueZ1); 

                X2 = Convert.ToDouble(valueX2); 
                Y2 = Convert.ToDouble(valueY2); 
                Z2 = Convert.ToDouble(valueZ2); 
            }

            public double CalcNewSurfaceArea() // Function CalcNewSurfaceArea() for calculating New Surface Area
            {
                Distance = (Math.Sqrt(Math.Pow((X2 - X1), 2) + Math.Pow((Y2 - Y1), 2) + Math.Pow((Z2 - Z1), 2))) / 1000;
                return Distance;
            }

            public double ColonizedArea() //Get Function CalcNewSurfaceArea() for calculating New Colonized
            {
               this.ColonizedAreaValue = (0.043 * (Math.Pow(10, -6) / (Math.Pow(this.New_Plante_Area, 1.6))));
                return this.ColonizedAreaValue;
            }
    }
}
